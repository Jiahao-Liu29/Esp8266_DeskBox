import { MPServerless } from './mpserverless';
export default MPServerless;
export { MPServerless };
