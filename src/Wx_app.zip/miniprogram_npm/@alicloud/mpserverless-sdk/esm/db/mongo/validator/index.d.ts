import { GenericObject, Validator } from './../../../core';
export declare class MongoValidator extends Validator {
    constructor(options?: GenericObject<any>);
}
