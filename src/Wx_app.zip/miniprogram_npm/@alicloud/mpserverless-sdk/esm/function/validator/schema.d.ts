export declare const invokeSchema: {
    functionTarget: {
        type: string;
        allowEmpty: boolean;
    };
};
