declare function ruleOfFileId(_: any, value: any): string;
declare const rules: {
    ruleOfFileId: typeof ruleOfFileId;
};
export { rules };
