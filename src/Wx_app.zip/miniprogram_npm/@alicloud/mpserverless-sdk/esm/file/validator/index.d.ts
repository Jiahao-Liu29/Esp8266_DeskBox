import { Validator, GenericObject } from './../../core';
export declare class FileValidator extends Validator {
    constructor(options?: GenericObject<any>);
}
export * from './schema';
