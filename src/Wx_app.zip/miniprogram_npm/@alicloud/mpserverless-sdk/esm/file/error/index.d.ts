declare const bizError: {
    [key: string]: typeof import("./../../core").ErrorClass;
};
export { bizError };
